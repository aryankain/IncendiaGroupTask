﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IncendiaGroupTask.Model
{
    public class AccountInfo
    {
        public int Id { get; set; }
        public decimal Balance { get; set; }
        public DateTime LastUpdatedDate { get; set; }

    }
}
